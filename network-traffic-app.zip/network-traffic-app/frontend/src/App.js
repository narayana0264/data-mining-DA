import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [response, setResponse] = useState('');
  const [timer, setTimer] = useState(0);
  const [isCapturing, setIsCapturing] = useState(false);
  const apiUrl = 'http://localhost:5000/api';

  useEffect(() => {
    let interval;
    if (isCapturing) {
      interval = setInterval(() => {
        setTimer((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isCapturing]);

  const handleGet = async () => {
    try {
      const res = await axios.get(`${apiUrl}/resource`);
      setResponse(JSON.stringify(res.data, null, 2));
    } catch (error) {
      setResponse('Error: ' + error.message);
    }
  };

  const handlePost = async () => {
    try {
      const res = await axios.post(`${apiUrl}/resource`, { name: 'New Resource' });
      setResponse(JSON.stringify(res.data, null, 2));
    } catch (error) {
      setResponse('Error: ' + error.message);
    }
  };

  const handlePut = async () => {
    try {
      const res = await axios.put(`${apiUrl}/resource`, { id: 1, name: 'Updated Resource (PUT)' });
      setResponse(JSON.stringify(res.data, null, 2));
    } catch (error) {
      setResponse('Error: ' + error.message);
    }
  };

  const handlePatch = async () => {
    try {
      const res = await axios.patch(`${apiUrl}/resource`, { name: 'Patched Resource' });
      setResponse(JSON.stringify(res.data, null, 2));
    } catch (error) {
      setResponse('Error: ' + error.message);
    }
  };

  const handleDelete = async () => {
    try {
      const res = await axios.delete(`${apiUrl}/resource`);
      setResponse(JSON.stringify(res.data, null, 2));
    } catch (error) {
      setResponse('Error: ' + error.message);
    }
  };

  const handleStartCapture = async () => {
    try {
      const res = await axios.get(`${apiUrl}/start-capture`);
      setResponse(JSON.stringify(res.data, null, 2));
      setIsCapturing(true);
      setTimer(0);
    } catch (error) {
      setResponse('Error: ' + error.message);
    }
  };

  const handleEndCapture = async () => {
    try {
      const res = await axios.get(`${apiUrl}/end-capture`);
      setResponse(JSON.stringify(res.data, null, 2));
    } catch (error) {
      setResponse('Error: ' + error.message);
    } finally {
      setIsCapturing(false);
    }
  };

  return (
    <div className="App">
      <h1>API Tester</h1>
      <div className="button-container">
        <button onClick={handleGet}>GET</button>
        <button onClick={handlePost}>POST</button>
        <button onClick={handlePut}>PUT</button>
        <button onClick={handlePatch}>PATCH</button>
        <button onClick={handleDelete}>DELETE</button>
      </div>
      <h1>Traffic Capture</h1>
      <div className="button-container">
        <button onClick={handleStartCapture} disabled={isCapturing}>
          Start Capture
        </button>
        <button onClick={handleEndCapture} disabled={!isCapturing}>
          End Capture
        </button>
      </div>
      {isCapturing && <h3>Capture Timer: {timer} seconds</h3>}
      <h3>Response:</h3>
      <pre>{response || 'Click a button to see the response'}</pre>
    </div>
  );
}

export default App;