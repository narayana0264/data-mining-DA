const express = require('express');
const router = express.Router();

// Dummy data to simulate a resource
let resource = { id: 1, name: "Sample Resource" };

// GET: Retrieve resource
router.get('/resource', (req, res) => {
  res.json(resource);
});

// POST: Create or update resource
router.post('/resource', (req, res) => {
  resource = { ...resource, ...req.body };
  res.status(201).json({ message: "Resource created", resource });
});

// PUT: Replace resource entirely
router.put('/resource', (req, res) => {
  resource = req.body;
  res.json({ message: "Resource updated (PUT)", resource });
});

// PATCH: Update resource partially
router.patch('/resource', (req, res) => {
  resource = { ...resource, ...req.body };
  res.json({ message: "Resource updated (PATCH)", resource });
});

// DELETE: Delete resource
router.delete('/resource', (req, res) => {
  resource = null;
  res.json({ message: "Resource deleted" });
});

module.exports = router;