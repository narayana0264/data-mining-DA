const express = require('express');
const cors = require('cors');
const { exec } = require('child-process-promise');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

let isCapturing = false;
let capturedRequests = [];

// Middleware to capture requests
app.use((req, res, next) => {
  if (isCapturing) {
    const requestData = {
      request: {
        method: req.method,
        url: req.url,
        timestamp_start: Date.now() / 1000, // Unix timestamp in seconds
        headers: req.headers,
        body: req.body || null
      }
    };

    // Capture response
    const originalSend = res.send;
    res.send = function (body) {
      requestData.response = {
        status: res.statusCode,
        headers: res.getHeaders(),
        body: body,
        timestamp_end: Date.now() / 1000
      };
      capturedRequests.push(requestData);
      originalSend.apply(res, arguments);
    };
  }
  next();
});

app.get('/api/start-capture', (req, res) => {
  if (isCapturing) {
    return res.status(400).json({ message: 'Capture already in progress' });
  }

  isCapturing = true;
  capturedRequests = [];
  res.json({ message: 'Capture started' });
});

app.get('/api/end-capture', async (req, res) => {
  if (!isCapturing) {
    return res.status(400).json({ message: 'No capture in progress' });
  }

  isCapturing = false;
  const outputPath = path.join(__dirname, '../data/raw/http_traffic.json');
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  // Write captured requests to JSON file
  fs.writeFileSync(outputPath, JSON.stringify(capturedRequests, null, 2));

  try {
    const result = await exec('python scripts/capture_http.py');
    console.log('Processing stdout:', result.stdout);
    console.log('Processing stderr:', result.stderr);
    res.json({ message: 'Capture stopped and features extracted' });
  } catch (error) {
    console.error('Processing error:', error.message);
    res.status(500).json({ error: 'Failed to process traffic', details: error.message });
  }
});

// Resource endpoints
let resource = { id: 1, name: 'Sample Resource' };

app.get('/api/resource', (req, res) => {
  res.json(resource);
});

app.post('/api/resource', (req, res) => {
  resource = { ...resource, ...req.body };
  res.status(201).json({ message: 'Resource created', resource });
});

app.put('/api/resource', (req, res) => {
  resource = req.body;
  res.json({ message: 'Resource updated (PUT)', resource });
});

app.patch('/api/resource', (req, res) => {
  resource = { ...resource, ...req.body };
  res.json({ message: 'Resource updated (PATCH)', resource });
});

app.delete('/api/resource', (req, res) => {
  resource = null;
  res.json({ message: 'Resource deleted' });
});

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});