import json
import pandas as pd
import os
import numpy as np

def extract_features():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_file = os.path.join(script_dir, "..", "..", "data", "raw", "http_traffic.json")
    output_file = os.path.join(script_dir, "..", "..", "data", "processed", "features.csv")

    if not os.path.exists(input_file):
        print(f"Input file {input_file} not found.")
        return

    with open(input_file, 'r') as f:
        requests = json.load(f)

    if not requests:
        print(f"No valid request data found in {input_file}.")
        return

    # Initialize parameters
    params = {
        'NUMBER_OF_REQUESTS': len(requests),
        'TOTAL_DURATION': 0,
        'AVERAGE_TIME': 0,
        'STANDARD_DEVIATION': 0,
        'REPEATED_REQUESTS': 0,
        'HTTP_RESPONSE_2XX': 0,
        'HTTP_RESPONSE_3XX': 0,
        'HTTP_RESPONSE_4XX': 0,
        'HTTP_RESPONSE_5XX': 0,
        'GET_METHOD': 0,
        'POST_METHOD': 0,
        'HEAD_METHOD': 0,
        'OTHER_METHOD': 0,
        'NIGHT': 0,
        'UNASSIGNED': 0,
        'IMAGES': 0,
        'TOTAL_HTML': 0,
        'HTML_TO_IMAGE': 0,
        'HTML_TO_CSS': 0,
        'HTML_TO_JS': 0,
        'WIDTH': 0,
        'DEPTH': 0,
        'STD_DEPTH': 0,
        'CONSECUTIVE': 0,
        'DATA': 0,
        'PPI': 0,
        'SF_REFERRER': 0,
        'SF_FILETYPE': 0,
        'MAX_BARRAGE': 0,
        'PENALTY': 0
    }

    # Process requests
    request_urls = {}
    timestamps = []
    for req in requests:
        method = req['request']['method']
        url = req['request']['url']
        timestamp_start = float(req['request']['timestamp_start'])
        timestamps.append(timestamp_start)

        if method == 'GET':
            params['GET_METHOD'] += 1
        elif method == 'POST':
            params['POST_METHOD'] += 1
        elif method == 'HEAD':
            params['HEAD_METHOD'] += 1
        else:
            params['OTHER_METHOD'] += 1

        request_urls[url] = request_urls.get(url, 0) + 1
        if request_urls[url] > 1:
            params['REPEATED_REQUESTS'] += 1

        if 'response' in req:
            status = req['response']['status']
            if 200 <= status < 300:
                params['HTTP_RESPONSE_2XX'] += 1
            elif 300 <= status < 400:
                params['HTTP_RESPONSE_3XX'] += 1
            elif 400 <= status < 500:
                params['HTTP_RESPONSE_4XX'] += 1
            elif 500 <= status < 600:
                params['HTTP_RESPONSE_5XX'] += 1

            # Check content type from headers
            content_type = req['response'].get('headers', {}).get('content-type', '').lower()
            if 'html' in content_type:
                params['TOTAL_HTML'] += 1
            elif 'image' in content_type:
                params['IMAGES'] += 1

    if timestamps:
        params['TOTAL_DURATION'] = max(timestamps) - min(timestamps)
        params['AVERAGE_TIME'] = params['TOTAL_DURATION'] / len(timestamps)
        iats = [t2 - t1 for t1, t2 in zip(timestamps[:-1], timestamps[1:])]
        params['STANDARD_DEVIATION'] = np.std(iats) if iats else 0

    # Save to CSV
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    df = pd.DataFrame([params])
    df.to_csv(output_file, index=False)
    print(f"Features saved to {output_file}")

if __name__ == "__main__":
    extract_features()