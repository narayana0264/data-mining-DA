pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()   // REQUIRED for KSP
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "iPic"
include(":app")