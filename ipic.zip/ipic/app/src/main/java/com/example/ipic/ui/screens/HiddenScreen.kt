@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ipic.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ipic.data.model.Photo
import com.example.ipic.ui.components.PhotoViewer
import com.example.ipic.ui.components.PinLockDialog
import com.example.ipic.viewmodel.GalleryViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HiddenScreen(
    viewModel: GalleryViewModel,
    onBack: () -> Unit
) {
    val hiddenPhotos by viewModel.hiddenPhotos.collectAsState()
    val isHiddenUnlocked by viewModel.isHiddenUnlocked.collectAsState()

    val hasPin = remember { viewModel.hasHiddenPin() }

    var showPinDialog by remember { mutableStateOf(false) }
    var isSettingPin by remember { mutableStateOf(!hasPin) }

    var columnCount by remember { mutableFloatStateOf(4f) }
    val actualColumnCount = columnCount.toInt().coerceIn(2, 8)

    var selectedPhotoIndex by remember { mutableIntStateOf(-1) }

    val sortedHiddenPhotos = remember(hiddenPhotos) {
        hiddenPhotos.sortedBy { it.dateTaken }
    }

    val gridState = rememberLazyGridState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        if (!isHiddenUnlocked) {
            isSettingPin = !viewModel.hasHiddenPin()
            showPinDialog = true
        }
    }

    LaunchedEffect(sortedHiddenPhotos.size, isHiddenUnlocked) {
        if (sortedHiddenPhotos.isNotEmpty() && isHiddenUnlocked) {
            coroutineScope.launch {
                gridState.scrollToItem(sortedHiddenPhotos.size - 1)
            }
        }
    }

    if (showPinDialog) {
        PinLockDialog(
            onDismiss = {
                showPinDialog = false
                if (!isHiddenUnlocked) {
                    onBack()
                }
            },
            onPinEntered = { pin ->
                if (isSettingPin) {
                    viewModel.setHiddenPin(pin)
                    showPinDialog = false
                    true
                } else {
                    val success = viewModel.unlockHidden(pin)
                    if (success) {
                        showPinDialog = false
                    }
                    success
                }
            },
            isSettingPin = isSettingPin
        )
    }

    if (selectedPhotoIndex >= 0 && selectedPhotoIndex < sortedHiddenPhotos.size && isHiddenUnlocked) {
        PhotoViewer(
            photos = sortedHiddenPhotos,
            initialIndex = selectedPhotoIndex,
            onDismiss = { lastIndex ->
                selectedPhotoIndex = -1
                coroutineScope.launch {
                    gridState.scrollToItem(lastIndex)
                }
            },
            onToggleFavorite = { photo -> viewModel.toggleFavorite(photo.id) },
            onToggleHidden = { photo -> viewModel.toggleHidden(photo.id) }
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Hidden",
                                fontWeight = FontWeight.SemiBold,
                                color = Color.Black
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            viewModel.lockHidden()
                            onBack()
                        }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color(0xFF007AFF)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.White
                    )
                )
            },
            containerColor = Color.White
        ) { padding ->
            when {
                !isHiddenUnlocked -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(32.dp)
                        ) {
                            Text(text = "🔒", fontSize = 64.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Hidden Album Locked",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.Black
                            )
                            Text(
                                text = "Enter your PIN to view hidden photos",
                                fontSize = 15.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            Button(
                                onClick = {
                                    isSettingPin = !viewModel.hasHiddenPin()
                                    showPinDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF007AFF)
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Unlock")
                            }
                        }
                    }
                }

                sortedHiddenPhotos.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "🔐", fontSize = 64.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "No Hidden Photos",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.Black
                            )
                            Text(
                                text = "Photos you hide will appear here",
                                fontSize = 15.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }

                else -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .pointerInput(Unit) {
                                awaitEachGesture {
                                    awaitFirstDown(requireUnconsumed = false)
                                    var isPinching = false
                                    do {
                                        val event = awaitPointerEvent(PointerEventPass.Initial)
                                        val fingerCount = event.changes.count { it.pressed }
                                        if (fingerCount >= 2) {
                                            isPinching = true
                                            val change1 = event.changes[0]
                                            val change2 = event.changes[1]
                                            val currentDistance = (change1.position - change2.position).getDistance()
                                            val previousDistance = (change1.previousPosition - change2.previousPosition).getDistance()
                                            if (previousDistance > 0f && currentDistance > 0f) {
                                                val zoomFactor = currentDistance / previousDistance
                                                if (zoomFactor != 1f) {
                                                    columnCount = (columnCount / zoomFactor).coerceIn(2f, 8f)
                                                }
                                            }
                                            event.changes.forEach { it.consume() }
                                        } else if (isPinching) {
                                            event.changes.forEach { it.consume() }
                                        }
                                    } while (event.changes.any { it.pressed })
                                }
                            }
                    ) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(actualColumnCount),
                            state = gridState,
                            contentPadding = PaddingValues(1.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(
                                items = sortedHiddenPhotos,
                                key = { it.id }
                            ) { photo ->
                                HiddenPhotoGridItem(
                                    photo = photo,
                                    onClick = {
                                        selectedPhotoIndex = sortedHiddenPhotos.indexOf(photo)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HiddenPhotoGridItem(
    photo: Photo,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .padding(0.5.dp)
            .clip(RoundedCornerShape(2.dp))
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(photo.uri)
                .crossfade(true)
                .build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}