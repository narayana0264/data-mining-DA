package com.example.ipic.util

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.ipic.data.model.Photo
import com.example.ipic.data.model.SystemAlbum
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Helper class for querying media from MediaStore
 * Handles all filesystem/media scanning logic
 */
@Singleton
class MediaStoreHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val contentResolver: ContentResolver = context.contentResolver
    
    // MediaStore collection URI
    private val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
    } else {
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }
    
    // Columns to query
    private val projection = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DISPLAY_NAME,
        MediaStore.Images.Media.DATE_TAKEN,
        MediaStore.Images.Media.DATE_MODIFIED,
        MediaStore.Images.Media.SIZE,
        MediaStore.Images.Media.WIDTH,
        MediaStore.Images.Media.HEIGHT,
        MediaStore.Images.Media.MIME_TYPE,
        MediaStore.Images.Media.BUCKET_ID,
        MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
        MediaStore.Images.Media.DATA // File path (deprecated but still useful)
    )
    
    /**
     * Scan all images from MediaStore
     * Returns list of Photo objects sorted by date
     */
    suspend fun scanAllPhotos(): List<Photo> = withContext(Dispatchers.IO) {
        val photos = mutableListOf<Photo>()
        
        val sortOrder = "${MediaStore.Images.Media.DATE_TAKEN} DESC, ${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        
        contentResolver.query(
            collection,
            projection,
            null,
            null,
            sortOrder
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val displayNameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val dateTakenColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
            val dateModifiedColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val widthColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val heightColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
            val mimeTypeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val bucketIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
            val bucketNameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val uri = ContentUris.withAppendedId(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    id
                )
                
                val photo = Photo(
                    id = id,
                    uri = uri.toString(),
                    displayName = cursor.getString(displayNameColumn) ?: "Unknown",
                    dateTaken = cursor.getLongOrNull(dateTakenColumn) ?: 0L,
                    dateModified = cursor.getLong(dateModifiedColumn) * 1000, // Convert to millis
                    size = cursor.getLong(sizeColumn),
                    width = cursor.getInt(widthColumn),
                    height = cursor.getInt(heightColumn),
                    mimeType = cursor.getString(mimeTypeColumn) ?: "image/*",
                    bucketId = cursor.getString(bucketIdColumn),
                    bucketName = cursor.getString(bucketNameColumn),
                    path = cursor.getString(dataColumn)
                )
                photos.add(photo)
            }
        }
        
        photos
    }
    
    /**
     * Get all system albums (folders with photos)
     */
    suspend fun getSystemAlbums(): List<SystemAlbum> = withContext(Dispatchers.IO) {
        val albums = mutableMapOf<String, SystemAlbum>()
        
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.DATA
        )
        
        contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.Images.Media.DATE_TAKEN} DESC"
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val bucketIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
            val bucketNameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            
            while (cursor.moveToNext()) {
                val bucketId = cursor.getString(bucketIdColumn) ?: continue
                val bucketName = cursor.getString(bucketNameColumn) ?: "Unknown"
                
                if (albums.containsKey(bucketId)) {
                    // Increment count
                    val existing = albums[bucketId]!!
                    albums[bucketId] = existing.copy(photoCount = existing.photoCount + 1)
                } else {
                    // First photo in bucket - use as cover
                    val id = cursor.getLong(idColumn)
                    val coverUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val path = cursor.getString(dataColumn)
                    val folderPath = path?.substringBeforeLast("/")
                    
                    albums[bucketId] = SystemAlbum(
                        bucketId = bucketId,
                        bucketName = bucketName,
                        photoCount = 1,
                        coverPhotoUri = coverUri.toString(),
                        folderPath = folderPath
                    )
                }
            }
        }
        
        albums.values.toList().sortedByDescending { it.photoCount }
    }
    
    /**
     * Get photos from a specific folder/bucket
     */
    suspend fun getPhotosFromBucket(bucketId: String): List<Photo> = withContext(Dispatchers.IO) {
        val photos = mutableListOf<Photo>()
        
        val selection = "${MediaStore.Images.Media.BUCKET_ID} = ?"
        val selectionArgs = arrayOf(bucketId)
        val sortOrder = "${MediaStore.Images.Media.DATE_TAKEN} DESC"
        
        contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            sortOrder
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val photo = cursorToPhoto(cursor)
                photos.add(photo)
            }
        }
        
        photos
    }
    
    /**
     * Delete photos from MediaStore (permanent delete)
     */
    suspend fun deletePhotos(photoIds: List<Long>): Boolean = withContext(Dispatchers.IO) {
        try {
            for (id in photoIds) {
                val uri = ContentUris.withAppendedId(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    id
                )
                contentResolver.delete(uri, null, null)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    
    private fun cursorToPhoto(cursor: Cursor): Photo {
        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val displayNameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
        val dateTakenColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
        val dateModifiedColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
        val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
        val widthColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
        val heightColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
        val mimeTypeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
        val bucketIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
        val bucketNameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
        val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        
        val id = cursor.getLong(idColumn)
        val uri = ContentUris.withAppendedId(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            id
        )
        
        return Photo(
            id = id,
            uri = uri.toString(),
            displayName = cursor.getString(displayNameColumn) ?: "Unknown",
            dateTaken = cursor.getLongOrNull(dateTakenColumn) ?: 0L,
            dateModified = cursor.getLong(dateModifiedColumn) * 1000,
            size = cursor.getLong(sizeColumn),
            width = cursor.getInt(widthColumn),
            height = cursor.getInt(heightColumn),
            mimeType = cursor.getString(mimeTypeColumn) ?: "image/*",
            bucketId = cursor.getString(bucketIdColumn),
            bucketName = cursor.getString(bucketNameColumn),
            path = cursor.getString(dataColumn)
        )
    }
    
    private fun Cursor.getLongOrNull(columnIndex: Int): Long? {
        return if (isNull(columnIndex)) null else getLong(columnIndex)
    }
}
