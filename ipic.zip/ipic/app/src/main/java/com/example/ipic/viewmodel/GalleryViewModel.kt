package com.example.ipic.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ipic.data.model.Photo
import com.example.ipic.data.repository.PhotoRepository
import com.example.ipic.util.PreferencesManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Main ViewModel for gallery operations
 * Handles library, favorites, hidden, and photo viewing
 */
@HiltViewModel
class GalleryViewModel @Inject constructor(
    private val repository: PhotoRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    // ============ UI STATE ============

    private val _uiState = MutableStateFlow(GalleryUiState())
    val uiState: StateFlow<GalleryUiState> = _uiState.asStateFlow()

    private val _selectedPhotos = MutableStateFlow<Set<Long>>(emptySet())
    val selectedPhotos: StateFlow<Set<Long>> = _selectedPhotos.asStateFlow()

    private val _isSelectionMode = MutableStateFlow(false)
    val isSelectionMode: StateFlow<Boolean> = _isSelectionMode.asStateFlow()

    private val _isHiddenUnlocked = MutableStateFlow(false)
    val isHiddenUnlocked: StateFlow<Boolean> = _isHiddenUnlocked.asStateFlow()

    // Grid columns from preferences
    val gridColumns: StateFlow<Int> = preferencesManager.gridColumns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 4)

    // ============ DATA FLOWS ============

    val allPhotos: StateFlow<List<Photo>> = repository.getAllPhotos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Visible photos (excludes hidden and deleted)
    val visiblePhotos: StateFlow<List<Photo>> = repository.getAllPhotos()
        .map { photos -> photos.filter { !it.isHidden && !it.isDeleted } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Favorite photos (excludes hidden and deleted)
    val favoritePhotos: StateFlow<List<Photo>> = repository.getFavoritePhotos()
        .map { photos -> photos.filter { !it.isHidden && !it.isDeleted } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Hidden photos
    val hiddenPhotos: StateFlow<List<Photo>> = repository.getHiddenPhotos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ============ INITIALIZATION ============

    fun loadPhotos() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                repository.syncPhotosFromMediaStore()
                _uiState.update { it.copy(isLoading = false, error = null) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    // ============ GRID CONTROL ============

    fun setGridColumns(columns: Int) {
        viewModelScope.launch {
            preferencesManager.setGridColumns(columns.coerceIn(2, 8))
        }
    }

    // ============ SELECTION ============

    fun toggleSelectionMode() {
        _isSelectionMode.update { !it }
        if (!_isSelectionMode.value) {
            _selectedPhotos.value = emptySet()
        }
    }

    fun togglePhotoSelection(photoId: Long) {
        _selectedPhotos.update { current ->
            if (photoId in current) {
                current - photoId
            } else {
                current + photoId
            }
        }
    }

    fun clearSelection() {
        _selectedPhotos.value = emptySet()
        _isSelectionMode.value = false
    }

    // ============ FAVORITES ============

    fun toggleFavorite(photoId: Long) {
        viewModelScope.launch {
            repository.toggleFavorite(photoId)
        }
    }

    // ============ HIDDEN ============

    fun toggleHidden(photoId: Long) {
        viewModelScope.launch {
            repository.toggleHidden(photoId)
        }
    }

    fun hideSelectedPhotos() {
        viewModelScope.launch {
            repository.hidePhotos(_selectedPhotos.value.toList())
            clearSelection()
        }
    }

    fun unhideSelectedPhotos() {
        viewModelScope.launch {
            repository.unhidePhotos(_selectedPhotos.value.toList())
            clearSelection()
        }
    }

    // ============ HIDDEN LOCK ============

    fun hasHiddenPin(): Boolean {
        return preferencesManager.hasHiddenPin()
    }

    fun setHiddenPin(pin: String) {
        preferencesManager.setHiddenPin(pin)
        _isHiddenUnlocked.value = true
    }

    fun unlockHidden(pin: String): Boolean {
        val isValid = preferencesManager.verifyHiddenPin(pin)
        if (isValid) {
            _isHiddenUnlocked.value = true
        }
        return isValid
    }

    fun lockHidden() {
        _isHiddenUnlocked.value = false
    }

    // ============ DELETE ============

    fun deleteSelectedPhotos() {
        viewModelScope.launch {
            repository.softDeletePhotos(_selectedPhotos.value.toList())
            clearSelection()
        }
    }
}

/**
 * UI State for gallery screens
 */
data class GalleryUiState(
    val isLoading: Boolean = false,
    val error: String? = null
)