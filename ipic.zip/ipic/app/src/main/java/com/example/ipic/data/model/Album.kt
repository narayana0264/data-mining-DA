package com.example.ipic.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a system album (folder-based)
 * Auto-generated from filesystem folders
 */
data class SystemAlbum(
    val bucketId: String,
    val bucketName: String,
    val photoCount: Int,
    val coverPhotoUri: String?,
    val folderPath: String?
) {
    companion object {
        // Common folder paths
        const val CAMERA_PATH = "DCIM/Camera"
        const val SCREENSHOTS_PATH = "Pictures/Screenshots"
        const val DOWNLOADS_PATH = "Download"
        const val WHATSAPP_PATH = "WhatsApp/Media/WhatsApp Images"
        const val TELEGRAM_PATH = "Telegram/Telegram Images"
    }
}

/**
 * Represents a user-created album
 * Stores references to photos, not copies
 */
@Entity(tableName = "user_albums")
data class UserAlbum(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val modifiedAt: Long = System.currentTimeMillis(),
    val coverPhotoId: Long? = null
)

/**
 * Junction table for user albums and photos
 * Many-to-many relationship
 */
@Entity(
    tableName = "album_photos",
    primaryKeys = ["albumId", "photoId"]
)
data class AlbumPhoto(
    val albumId: Long,
    val photoId: Long,
    val addedAt: Long = System.currentTimeMillis()
)

/**
 * Album with photo count for display
 */
data class AlbumWithCount(
    val album: UserAlbum,
    val photoCount: Int,
    val coverPhotoUri: String?
)

/**
 * Special album types
 */
enum class SpecialAlbum {
    ALL_PHOTOS,
    FAVORITES,
    HIDDEN,
    RECENTLY_DELETED
}
