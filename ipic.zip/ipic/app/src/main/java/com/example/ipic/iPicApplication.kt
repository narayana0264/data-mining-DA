package com.example.ipic

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class iPicApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
