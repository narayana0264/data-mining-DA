@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ipic.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ipic.data.model.Photo
import com.example.ipic.ui.components.PhotoViewer
import com.example.ipic.viewmodel.GalleryViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    viewModel: GalleryViewModel,
    onBack: () -> Unit
) {
    val favoritePhotos by viewModel.favoritePhotos.collectAsState()

    val sortedFavorites = remember(favoritePhotos) {
        favoritePhotos.filter { !it.isHidden && !it.isDeleted }.sortedBy { it.dateTaken }
    }

    var columnCount by remember { mutableFloatStateOf(4f) }
    val actualColumnCount = columnCount.toInt().coerceIn(2, 8)

    var selectedPhotoIndex by remember { mutableIntStateOf(-1) }

    val gridState = rememberLazyGridState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(sortedFavorites.size) {
        if (sortedFavorites.isNotEmpty()) {
            coroutineScope.launch {
                gridState.scrollToItem(sortedFavorites.size - 1)
            }
        }
    }

    if (selectedPhotoIndex >= 0 && selectedPhotoIndex < sortedFavorites.size) {
        PhotoViewer(
            photos = sortedFavorites,
            initialIndex = selectedPhotoIndex,
            onDismiss = { lastIndex ->
                selectedPhotoIndex = -1
                coroutineScope.launch {
                    gridState.scrollToItem(lastIndex)
                }
            },
            onToggleFavorite = { photo -> viewModel.toggleFavorite(photo.id) },
            onToggleHidden = { photo -> viewModel.toggleHidden(photo.id) }
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = Color(0xFFFF9500),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Favorites",
                                fontWeight = FontWeight.SemiBold,
                                color = Color.Black
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color(0xFF007AFF)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.White
                    )
                )
            },
            containerColor = Color.White
        ) { padding ->
            if (sortedFavorites.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "❤️", fontSize = 64.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No Favorites Yet",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Black
                        )
                        Text(
                            text = "Photos you favorite will appear here",
                            fontSize = 15.sp,
                            color = Color.Gray
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                var isPinching = false
                                do {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    val fingerCount = event.changes.count { it.pressed }
                                    if (fingerCount >= 2) {
                                        isPinching = true
                                        val change1 = event.changes[0]
                                        val change2 = event.changes[1]
                                        val currentDistance = (change1.position - change2.position).getDistance()
                                        val previousDistance = (change1.previousPosition - change2.previousPosition).getDistance()
                                        if (previousDistance > 0f && currentDistance > 0f) {
                                            val zoomFactor = currentDistance / previousDistance
                                            if (zoomFactor != 1f) {
                                                columnCount = (columnCount / zoomFactor).coerceIn(2f, 8f)
                                            }
                                        }
                                        event.changes.forEach { it.consume() }
                                    } else if (isPinching) {
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(actualColumnCount),
                        state = gridState,
                        contentPadding = PaddingValues(1.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(
                            items = sortedFavorites,
                            key = { it.id }
                        ) { photo ->
                            FavoritePhotoGridItem(
                                photo = photo,
                                onClick = {
                                    selectedPhotoIndex = sortedFavorites.indexOf(photo)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoritePhotoGridItem(
    photo: Photo,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .padding(0.5.dp)
            .clip(RoundedCornerShape(2.dp))
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(photo.uri)
                .crossfade(true)
                .build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Icon(
            imageVector = Icons.Default.Favorite,
            contentDescription = "Favorite",
            tint = Color.White,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(4.dp)
                .size(16.dp)
        )
    }
}