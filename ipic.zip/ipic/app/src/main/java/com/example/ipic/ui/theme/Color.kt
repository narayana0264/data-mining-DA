package com.example.ipic.ui.theme

import androidx.compose.ui.graphics.Color

// iOS Light Theme Color Palette - Pure White Theme
val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)

// Backgrounds (Light iOS style)
val SystemBackground = Color(0xFFFFFFFF)
val SecondaryBackground = Color(0xFFF2F2F7)
val TertiaryBackground = Color(0xFFE5E5EA)

// Primary Blues (iOS style)
val Blue = Color(0xFF007AFF)

// System Grays
val Gray = Color(0xFF8E8E93)
val Gray2 = Color(0xFFAEAEB2)
val Gray3 = Color(0xFFC7C7CC)
val Gray4 = Color(0xFFD1D1D6)
val Gray5 = Color(0xFFE5E5EA)
val Gray6 = Color(0xFFF2F2F7)

// Semantic Colors
val Red = Color(0xFFFF3B30)
val Orange = Color(0xFFFF9500)
val Yellow = Color(0xFFFFCC00)
val Green = Color(0xFF34C759)
val Teal = Color(0xFF5AC8FA)
val Indigo = Color(0xFF5856D6)
val Pink = Color(0xFFFF2D55)

// For favorites
val FavoriteYellow = Color(0xFFFFD60A)

// Separator
val Separator = Color(0xFFC6C6C8)
