package com.example.ipic.data.repository

import com.example.ipic.data.database.AlbumDao
import com.example.ipic.data.database.PhotoDao
import com.example.ipic.data.model.*
import com.example.ipic.util.MediaStoreHelper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for photo data
 * Coordinates between MediaStore and Room database
 */
@Singleton
class PhotoRepository @Inject constructor(
    private val photoDao: PhotoDao,
    private val albumDao: AlbumDao,
    private val mediaStoreHelper: MediaStoreHelper
) {
    
    // ============ PHOTO OPERATIONS ============
    
    /**
     * Get all photos (excluding hidden and deleted)
     */
    fun getAllPhotos(): Flow<List<Photo>> = photoDao.getAllVisiblePhotos()
    
    /**
     * Get single photo by ID
     */
    suspend fun getPhotoById(id: Long): Photo? = photoDao.getPhotoById(id)
    
    /**
     * Get photo flow by ID (reactive)
     */
    fun getPhotoByIdFlow(id: Long): Flow<Photo?> = photoDao.getPhotoByIdFlow(id)
    
    /**
     * Scan MediaStore and sync to database
     */
    suspend fun syncPhotosFromMediaStore(): Int {
        val mediaPhotos = mediaStoreHelper.scanAllPhotos()
        
        // Get existing photos to preserve flags
        val existingPhotos = photoDao.getAllVisiblePhotos().first().associateBy { it.id }
        
        // Merge: keep favorite/hidden flags from existing
        val mergedPhotos = mediaPhotos.map { mediaPhoto ->
            val existing = existingPhotos[mediaPhoto.id]
            if (existing != null) {
                mediaPhoto.copy(
                    isFavorite = existing.isFavorite,
                    isHidden = existing.isHidden,
                    isDeleted = existing.isDeleted,
                    deletedAt = existing.deletedAt
                )
            } else {
                mediaPhoto
            }
        }
        
        photoDao.insertPhotos(mergedPhotos)
        return mergedPhotos.size
    }
    
    // ============ FAVORITES ============
    
    /**
     * Get all favorite photos
     */
    fun getFavoritePhotos(): Flow<List<Photo>> = photoDao.getFavoritePhotos()
    
    /**
     * Toggle favorite status
     */
    suspend fun toggleFavorite(photoId: Long) {
        val photo = photoDao.getPhotoById(photoId)
        if (photo != null) {
            photoDao.setFavorite(photoId, !photo.isFavorite)
        }
    }
    
    /**
     * Add photos to favorites
     */
    suspend fun addToFavorites(photoIds: List<Long>) {
        photoDao.addToFavorites(photoIds)
    }
    
    /**
     * Remove photos from favorites
     */
    suspend fun removeFromFavorites(photoIds: List<Long>) {
        photoDao.removeFromFavorites(photoIds)
    }
    
    // ============ HIDDEN ============
    
    /**
     * Get all hidden photos
     */
    fun getHiddenPhotos(): Flow<List<Photo>> = photoDao.getHiddenPhotos()
    
    /**
     * Toggle hidden status
     */
    suspend fun toggleHidden(photoId: Long) {
        val photo = photoDao.getPhotoById(photoId)
        if (photo != null) {
            photoDao.setHidden(photoId, !photo.isHidden)
        }
    }
    
    /**
     * Hide photos
     */
    suspend fun hidePhotos(photoIds: List<Long>) {
        photoDao.hidePhotos(photoIds)
    }
    
    /**
     * Unhide photos
     */
    suspend fun unhidePhotos(photoIds: List<Long>) {
        photoDao.unhidePhotos(photoIds)
    }
    
    // ============ DELETE ============
    
    /**
     * Get recently deleted photos
     */
    fun getRecentlyDeletedPhotos(): Flow<List<Photo>> = photoDao.getRecentlyDeletedPhotos()
    
    /**
     * Soft delete photos (move to recently deleted)
     */
    suspend fun softDeletePhotos(photoIds: List<Long>) {
        photoDao.softDeletePhotos(photoIds)
    }
    
    /**
     * Restore photos from recently deleted
     */
    suspend fun restorePhotos(photoIds: List<Long>) {
        photoDao.restorePhotos(photoIds)
    }
    
    /**
     * Permanently delete photos
     */
    suspend fun permanentlyDeletePhotos(photoIds: List<Long>) {
        // Delete from MediaStore
        mediaStoreHelper.deletePhotos(photoIds)
        // Remove from database
        photoDao.permanentlyDeletePhotos(photoIds)
    }
    
    // ============ ALBUMS - SYSTEM ============
    
    /**
     * Get system albums (folders)
     */
    suspend fun getSystemAlbums(): List<SystemAlbum> {
        return mediaStoreHelper.getSystemAlbums()
    }
    
    /**
     * Get photos by bucket/folder
     */
    fun getPhotosByBucket(bucketId: String): Flow<List<Photo>> {
        return photoDao.getPhotosByBucket(bucketId)
    }
    
    // ============ ALBUMS - USER ============
    
    /**
     * Get all user albums
     */
    fun getUserAlbums(): Flow<List<UserAlbum>> = albumDao.getAllUserAlbums()
    
    /**
     * Create new user album
     */
    suspend fun createAlbum(name: String): Long {
        val album = UserAlbum(name = name)
        return albumDao.createAlbum(album)
    }
    
    /**
     * Rename album
     */
    suspend fun renameAlbum(albumId: Long, newName: String) {
        val album = albumDao.getAlbumById(albumId)
        if (album != null) {
            albumDao.updateAlbum(album.copy(name = newName, modifiedAt = System.currentTimeMillis()))
        }
    }
    
    /**
     * Delete user album
     */
    suspend fun deleteAlbum(albumId: Long) {
        val album = albumDao.getAlbumById(albumId)
        if (album != null) {
            albumDao.clearAlbum(albumId)
            albumDao.deleteAlbum(album)
        }
    }
    
    /**
     * Add photos to album
     */
    suspend fun addPhotosToAlbum(albumId: Long, photoIds: List<Long>) {
        val albumPhotos = photoIds.map { photoId ->
            AlbumPhoto(albumId = albumId, photoId = photoId)
        }
        albumDao.addPhotosToAlbum(albumPhotos)
        
        // Update album modified time
        val album = albumDao.getAlbumById(albumId)
        if (album != null) {
            albumDao.updateAlbum(album.copy(modifiedAt = System.currentTimeMillis()))
        }
    }
    
    /**
     * Remove photos from album
     */
    suspend fun removePhotosFromAlbum(albumId: Long, photoIds: List<Long>) {
        albumDao.removePhotosFromAlbum(albumId, photoIds)
    }
    
    /**
     * Get photos in user album
     */
    fun getPhotosInAlbum(albumId: Long): Flow<List<Photo>> {
        return albumDao.getPhotosInAlbum(albumId)
    }
    
    // ============ COUNTS ============
    
    fun getTotalPhotoCount(): Flow<Int> = photoDao.getTotalPhotoCount()
    fun getFavoriteCount(): Flow<Int> = photoDao.getFavoriteCount()
    fun getHiddenCount(): Flow<Int> = photoDao.getHiddenCount()
}
