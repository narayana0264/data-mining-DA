package com.example.ipic.di

import android.content.Context
import com.example.ipic.data.database.AlbumDao
import com.example.ipic.data.database.AppDatabase
import com.example.ipic.data.database.PhotoDao
import com.example.ipic.data.repository.PhotoRepository
import com.example.ipic.util.MediaStoreHelper
import com.example.ipic.util.PreferencesManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt module for dependency injection
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    
    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getDatabase(context)
    }
    
    @Provides
    @Singleton
    fun providePhotoDao(database: AppDatabase): PhotoDao {
        return database.photoDao()
    }
    
    @Provides
    @Singleton
    fun provideAlbumDao(database: AppDatabase): AlbumDao {
        return database.albumDao()
    }
    
    @Provides
    @Singleton
    fun provideMediaStoreHelper(@ApplicationContext context: Context): MediaStoreHelper {
        return MediaStoreHelper(context)
    }
    
    @Provides
    @Singleton
    fun providePreferencesManager(@ApplicationContext context: Context): PreferencesManager {
        return PreferencesManager(context)
    }
    
    @Provides
    @Singleton
    fun providePhotoRepository(
        photoDao: PhotoDao,
        albumDao: AlbumDao,
        mediaStoreHelper: MediaStoreHelper
    ): PhotoRepository {
        return PhotoRepository(photoDao, albumDao, mediaStoreHelper)
    }
}
