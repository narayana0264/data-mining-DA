package com.example.ipic.data.database

import androidx.room.*
import com.example.ipic.data.model.AlbumPhoto
import com.example.ipic.data.model.Photo
import com.example.ipic.data.model.UserAlbum
import kotlinx.coroutines.flow.Flow

@Dao
interface PhotoDao {
    
    // ============ INSERT/UPDATE ============
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: Photo)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotos(photos: List<Photo>)
    
    @Update
    suspend fun updatePhoto(photo: Photo)
    
    // ============ QUERIES ============
    
    /**
     * Get all visible photos (not hidden, not deleted)
     * Sorted by date_taken DESC, then date_modified DESC
     * Newest first (for iOS-style bottom-to-top scroll)
     */
    @Query("""
        SELECT * FROM photos 
        WHERE isHidden = 0 AND isDeleted = 0 
        ORDER BY dateTaken DESC, dateModified DESC
    """)
    fun getAllVisiblePhotos(): Flow<List<Photo>>
    
    /**
     * Get photos with pagination for lazy loading
     */
    @Query("""
        SELECT * FROM photos 
        WHERE isHidden = 0 AND isDeleted = 0 
        ORDER BY dateTaken DESC, dateModified DESC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getVisiblePhotosPaged(limit: Int, offset: Int): List<Photo>
    
    /**
     * Get photo by ID
     */
    @Query("SELECT * FROM photos WHERE id = :id")
    suspend fun getPhotoById(id: Long): Photo?
    
    @Query("SELECT * FROM photos WHERE id = :id")
    fun getPhotoByIdFlow(id: Long): Flow<Photo?>
    
    /**
     * Get photos by folder/bucket
     */
    @Query("""
        SELECT * FROM photos 
        WHERE bucketId = :bucketId AND isHidden = 0 AND isDeleted = 0
        ORDER BY dateTaken DESC
    """)
    fun getPhotosByBucket(bucketId: String): Flow<List<Photo>>
    
    /**
     * Get all favorite photos
     */
    @Query("""
        SELECT * FROM photos 
        WHERE isFavorite = 1 AND isHidden = 0 AND isDeleted = 0
        ORDER BY dateTaken DESC
    """)
    fun getFavoritePhotos(): Flow<List<Photo>>
    
    /**
     * Get all hidden photos
     */
    @Query("""
        SELECT * FROM photos 
        WHERE isHidden = 1 AND isDeleted = 0
        ORDER BY dateTaken DESC
    """)
    fun getHiddenPhotos(): Flow<List<Photo>>
    
    /**
     * Get recently deleted photos
     */
    @Query("""
        SELECT * FROM photos 
        WHERE isDeleted = 1
        ORDER BY deletedAt DESC
    """)
    fun getRecentlyDeletedPhotos(): Flow<List<Photo>>
    
    /**
     * Get distinct buckets (folders) for system albums
     */
    @Query("""
        SELECT DISTINCT bucketId, bucketName, COUNT(*) as count
        FROM photos 
        WHERE isHidden = 0 AND isDeleted = 0 AND bucketId IS NOT NULL
        GROUP BY bucketId
        ORDER BY count DESC
    """)
    fun getSystemAlbums(): Flow<List<BucketInfo>>
    
    // ============ FAVORITES ============
    
    @Query("UPDATE photos SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: Long, isFavorite: Boolean)
    
    @Query("UPDATE photos SET isFavorite = 1 WHERE id IN (:ids)")
    suspend fun addToFavorites(ids: List<Long>)
    
    @Query("UPDATE photos SET isFavorite = 0 WHERE id IN (:ids)")
    suspend fun removeFromFavorites(ids: List<Long>)
    
    // ============ HIDDEN ============
    
    @Query("UPDATE photos SET isHidden = :isHidden WHERE id = :id")
    suspend fun setHidden(id: Long, isHidden: Boolean)
    
    @Query("UPDATE photos SET isHidden = 1 WHERE id IN (:ids)")
    suspend fun hidePhotos(ids: List<Long>)
    
    @Query("UPDATE photos SET isHidden = 0 WHERE id IN (:ids)")
    suspend fun unhidePhotos(ids: List<Long>)
    
    // ============ DELETE ============
    
    @Query("UPDATE photos SET isDeleted = 1, deletedAt = :deletedAt WHERE id IN (:ids)")
    suspend fun softDeletePhotos(ids: List<Long>, deletedAt: Long = System.currentTimeMillis())
    
    @Query("UPDATE photos SET isDeleted = 0, deletedAt = NULL WHERE id IN (:ids)")
    suspend fun restorePhotos(ids: List<Long>)
    
    @Query("DELETE FROM photos WHERE id IN (:ids)")
    suspend fun permanentlyDeletePhotos(ids: List<Long>)
    
    /**
     * Delete photos older than retention period
     */
    @Query("DELETE FROM photos WHERE isDeleted = 1 AND deletedAt < :threshold")
    suspend fun purgeOldDeletedPhotos(threshold: Long)
    
    // ============ COUNTS ============
    
    @Query("SELECT COUNT(*) FROM photos WHERE isHidden = 0 AND isDeleted = 0")
    fun getTotalPhotoCount(): Flow<Int>
    
    @Query("SELECT COUNT(*) FROM photos WHERE isFavorite = 1 AND isHidden = 0 AND isDeleted = 0")
    fun getFavoriteCount(): Flow<Int>
    
    @Query("SELECT COUNT(*) FROM photos WHERE isHidden = 1 AND isDeleted = 0")
    fun getHiddenCount(): Flow<Int>
}

/**
 * Bucket info for system albums
 */
data class BucketInfo(
    val bucketId: String?,
    val bucketName: String?,
    val count: Int
)

@Dao
interface AlbumDao {
    
    // ============ USER ALBUMS ============
    
    @Insert
    suspend fun createAlbum(album: UserAlbum): Long
    
    @Update
    suspend fun updateAlbum(album: UserAlbum)
    
    @Delete
    suspend fun deleteAlbum(album: UserAlbum)
    
    @Query("SELECT * FROM user_albums ORDER BY modifiedAt DESC")
    fun getAllUserAlbums(): Flow<List<UserAlbum>>
    
    @Query("SELECT * FROM user_albums WHERE id = :id")
    suspend fun getAlbumById(id: Long): UserAlbum?
    
    // ============ ALBUM PHOTOS ============
    
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addPhotoToAlbum(albumPhoto: AlbumPhoto)
    
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addPhotosToAlbum(albumPhotos: List<AlbumPhoto>)
    
    @Delete
    suspend fun removePhotoFromAlbum(albumPhoto: AlbumPhoto)
    
    @Query("DELETE FROM album_photos WHERE albumId = :albumId AND photoId IN (:photoIds)")
    suspend fun removePhotosFromAlbum(albumId: Long, photoIds: List<Long>)
    
    @Query("DELETE FROM album_photos WHERE albumId = :albumId")
    suspend fun clearAlbum(albumId: Long)
    
    /**
     * Get all photos in a user album
     */
    @Query("""
        SELECT p.* FROM photos p
        INNER JOIN album_photos ap ON p.id = ap.photoId
        WHERE ap.albumId = :albumId AND p.isHidden = 0 AND p.isDeleted = 0
        ORDER BY ap.addedAt DESC
    """)
    fun getPhotosInAlbum(albumId: Long): Flow<List<Photo>>
    
    /**
     * Get photo count for album
     */
    @Query("""
        SELECT COUNT(*) FROM album_photos ap
        INNER JOIN photos p ON p.id = ap.photoId
        WHERE ap.albumId = :albumId AND p.isHidden = 0 AND p.isDeleted = 0
    """)
    fun getAlbumPhotoCount(albumId: Long): Flow<Int>
    
    /**
     * Get first photo in album for cover
     */
    @Query("""
        SELECT p.uri FROM photos p
        INNER JOIN album_photos ap ON p.id = ap.photoId
        WHERE ap.albumId = :albumId AND p.isHidden = 0 AND p.isDeleted = 0
        ORDER BY ap.addedAt DESC
        LIMIT 1
    """)
    suspend fun getAlbumCoverUri(albumId: Long): String?
}
