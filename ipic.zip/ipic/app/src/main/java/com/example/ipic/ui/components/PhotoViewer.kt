@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.example.ipic.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ipic.data.model.Photo
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

@Composable
fun PhotoViewer(
    photos: List<Photo>,
    initialIndex: Int,
    onDismiss: (Int) -> Unit,
    onToggleFavorite: (Photo) -> Unit,
    onToggleHidden: (Photo) -> Unit
) {
    val pagerState = rememberPagerState(
        initialPage = initialIndex,
        pageCount = { photos.size }
    )
    
    var showUI by remember { mutableStateOf(true) }
    var showMetadataSheet by remember { mutableStateOf(false) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }
    
    val currentPhoto = photos.getOrNull(pagerState.currentPage)
    
    // Metadata Bottom Sheet
    if (showMetadataSheet && currentPhoto != null) {
        ModalBottomSheet(
            onDismissRequest = { showMetadataSheet = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        ) {
            MetadataContent(
                photo = currentPhoto,
                onToggleFavorite = { onToggleFavorite(currentPhoto) },
                onToggleHidden = { onToggleHidden(currentPhoto) }
            )
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Photo Pager with swipe gestures
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    // Apply vertical drag offset for dismiss animation
                    translationY = dragOffsetY
                    // Scale down as user drags
                    val scale = 1f - (abs(dragOffsetY) / 2000f).coerceIn(0f, 0.3f)
                    scaleX = scale
                    scaleY = scale
                }
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = {
                            isDragging = true
                        },
                        onDragEnd = {
                            isDragging = false
                            // Swipe down to dismiss (drag > 150px downward)
                            if (dragOffsetY > 150f) {
                                onDismiss(pagerState.currentPage)
                            }
                            // Swipe up to show metadata (drag > 100px upward)
                            else if (dragOffsetY < -100f) {
                                showMetadataSheet = true
                            }
                            dragOffsetY = 0f
                        },
                        onDragCancel = {
                            isDragging = false
                            dragOffsetY = 0f
                        },
                        onVerticalDrag = { _, dragAmount ->
                            dragOffsetY += dragAmount
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { showUI = !showUI },
                        onDoubleTap = { /* Could implement double-tap zoom */ }
                    )
                }
        ) { page ->
            val photo = photos[page]
            
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(photo.uri)
                    .crossfade(true)
                    .build(),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }
        
        // Top Bar UI
        AnimatedVisibility(
            visible = showUI && !isDragging,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            TopAppBar(
                title = {
                    currentPhoto?.let { photo ->
                        Column {
                            Text(
                                text = formatDate(photo.dateTaken),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Text(
                                text = formatTime(photo.dateTaken),
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { onDismiss(pagerState.currentPage) }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Black.copy(alpha = 0.5f)
                ),
                modifier = Modifier.statusBarsPadding()
            )
        }
        
        // Bottom Actions UI
        AnimatedVisibility(
            visible = showUI && !isDragging,
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            BottomActionsBar(
                photo = currentPhoto,
                onToggleFavorite = { currentPhoto?.let { onToggleFavorite(it) } },
                onToggleHidden = { currentPhoto?.let { onToggleHidden(it) } },
                onShowMetadata = { showMetadataSheet = true }
            )
        }
        
        // Swipe hint indicator
        if (isDragging) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 60.dp)
            ) {
                if (dragOffsetY < -50f) {
                    Text(
                        text = "↑ Release for details",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                } else if (dragOffsetY > 50f) {
                    Text(
                        text = "↓ Release to close",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomActionsBar(
    photo: Photo?,
    onToggleFavorite: () -> Unit,
    onToggleHidden: () -> Unit,
    onShowMetadata: () -> Unit
) {
    Surface(
        color = Color.Black.copy(alpha = 0.5f),
        modifier = Modifier.navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Share
            IconButton(onClick = { /* Share */ }) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            // Favorite
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (photo?.isFavorite == true) Icons.Filled.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (photo?.isFavorite == true) Color(0xFFFF9500) else Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            // Info (swipe up hint)
            IconButton(onClick = onShowMetadata) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Info",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            // Hide
            IconButton(onClick = onToggleHidden) {
                Icon(
                    imageVector = if (photo?.isHidden == true) Icons.Default.Lock else Icons.Default.VisibilityOff,
                    contentDescription = "Hide",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
            
            // Delete
            IconButton(onClick = { /* Delete */ }) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

@Composable
private fun MetadataContent(
    photo: Photo,
    onToggleFavorite: () -> Unit,
    onToggleHidden: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
            .padding(bottom = 32.dp)
    ) {
        // Title
        Text(
            text = "Photo Details",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Date & Time
        MetadataRow(
            icon = Icons.Default.DateRange,
            label = "Date",
            value = formatFullDate(photo.dateTaken)
        )
        
        MetadataRow(
            icon = Icons.Default.AccessTime,
            label = "Time",
            value = formatFullTime(photo.dateTaken)
        )
        
        // File Info - use displayName from Photo model
        MetadataRow(
            icon = Icons.Default.Image,
            label = "File Name",
            value = photo.displayName
        )
        
        MetadataRow(
            icon = Icons.Default.Folder,
            label = "Folder",
            value = photo.bucketName ?: "Unknown"
        )
        
        if (photo.size > 0) {
            MetadataRow(
                icon = Icons.Default.Storage,
                label = "Size",
                value = formatFileSize(photo.size)
            )
        }
        
        if (photo.width > 0 && photo.height > 0) {
            MetadataRow(
                icon = Icons.Default.AspectRatio,
                label = "Dimensions",
                value = "${photo.width} × ${photo.height}"
            )
        }
        
        MetadataRow(
            icon = Icons.Default.Category,
            label = "Type",
            value = photo.mimeType
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Quick Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Favorite Button
            OutlinedButton(
                onClick = onToggleFavorite,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (photo.isFavorite) Color(0xFFFF9500) else Color.Gray
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = if (photo.isFavorite) Icons.Filled.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (photo.isFavorite) "Favorited" else "Favorite")
            }
            
            // Hide Button
            OutlinedButton(
                onClick = onToggleHidden,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color.Gray
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.VisibilityOff,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (photo.isHidden) "Unhide" else "Hide")
            }
        }
    }
}

@Composable
private fun MetadataRow(
    icon: ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = label,
                fontSize = 12.sp,
                color = Color.Gray
            )
            Text(
                text = value,
                fontSize = 15.sp,
                color = Color.Black
            )
        }
    }
}

// Helper functions
private fun formatDate(timestamp: Long): String {
    return SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(timestamp))
}

private fun formatTime(timestamp: Long): String {
    return SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(timestamp))
}

private fun formatFullDate(timestamp: Long): String {
    return SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date(timestamp))
}

private fun formatFullTime(timestamp: Long): String {
    return SimpleDateFormat("h:mm:ss a", Locale.getDefault()).format(Date(timestamp))
}

private fun formatFileSize(bytes: Long): String {
    return when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        bytes < 1024 * 1024 * 1024 -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        else -> String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    }
}
