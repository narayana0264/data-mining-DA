@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ipic.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ipic.data.model.Photo
import com.example.ipic.ui.components.PhotoViewer
import com.example.ipic.viewmodel.GalleryViewModel
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    viewModel: GalleryViewModel,
    onNavigateToFavorites: () -> Unit,
    onNavigateToHidden: () -> Unit
) {
    val context = LocalContext.current
    val photos by viewModel.visiblePhotos.collectAsState()

    var hasPermission by remember { mutableStateOf(false) }
    var selectedPhotoIndex by remember { mutableIntStateOf(-1) }

    var columnCount by remember { mutableFloatStateOf(4f) }
    val actualColumnCount = columnCount.toInt().coerceIn(2, 8)

    val gridState = rememberLazyGridState()
    val coroutineScope = rememberCoroutineScope()

    val sortedPhotos = remember(photos) {
        photos.sortedBy { it.dateTaken }
    }

    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_IMAGES
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasPermission = isGranted
        if (isGranted) {
            viewModel.loadPhotos()
        }
    }

    LaunchedEffect(Unit) {
        hasPermission = ContextCompat.checkSelfPermission(
            context, permission
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.loadPhotos()
        } else {
            permissionLauncher.launch(permission)
        }
    }

    LaunchedEffect(sortedPhotos.size) {
        if (sortedPhotos.isNotEmpty()) {
            coroutineScope.launch {
                gridState.scrollToItem(sortedPhotos.size - 1)
            }
        }
    }

    if (selectedPhotoIndex >= 0 && selectedPhotoIndex < sortedPhotos.size) {
        PhotoViewer(
            photos = sortedPhotos,
            initialIndex = selectedPhotoIndex,
            onDismiss = { lastIndex ->
                selectedPhotoIndex = -1
                coroutineScope.launch {
                    gridState.scrollToItem(lastIndex)
                }
            },
            onToggleFavorite = { photo -> viewModel.toggleFavorite(photo.id) },
            onToggleHidden = { photo -> viewModel.toggleHidden(photo.id) }
        )
    } else {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
        ) {
            if (!hasPermission) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "📷",
                        fontSize = 64.sp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "Photo Access Required",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "iPic needs access to your photos to display your gallery",
                        fontSize = 15.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    Button(
                        onClick = { permissionLauncher.launch(permission) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF007AFF)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Text(
                            text = "Grant Permission",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else if (sortedPhotos.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "📷",
                        fontSize = 64.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Photos",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.Black
                    )
                    Text(
                        text = "Your photos will appear here",
                        fontSize = 15.sp,
                        color = Color.Gray
                    )
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .pointerInput(Unit) {
                                awaitEachGesture {
                                    awaitFirstDown(requireUnconsumed = false)
                                    var isPinching = false
                                    do {
                                        val event = awaitPointerEvent(PointerEventPass.Initial)
                                        val fingerCount = event.changes.count { it.pressed }
                                        if (fingerCount >= 2) {
                                            isPinching = true
                                            val change1 = event.changes[0]
                                            val change2 = event.changes[1]
                                            val currentDistance = (change1.position - change2.position).getDistance()
                                            val previousDistance = (change1.previousPosition - change2.previousPosition).getDistance()
                                            if (previousDistance > 0f && currentDistance > 0f) {
                                                val zoomFactor = currentDistance / previousDistance
                                                if (zoomFactor != 1f) {
                                                    columnCount = (columnCount / zoomFactor).coerceIn(2f, 8f)
                                                }
                                            }
                                            event.changes.forEach { it.consume() }
                                        } else if (isPinching) {
                                            event.changes.forEach { it.consume() }
                                        }
                                    } while (event.changes.any { it.pressed })
                                }
                            }
                    ) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(actualColumnCount),
                            state = gridState,
                            contentPadding = PaddingValues(1.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(
                                items = sortedPhotos,
                                key = { it.id }
                            ) { photo ->
                                PhotoGridItem(
                                    photo = photo,
                                    onClick = {
                                        selectedPhotoIndex = sortedPhotos.indexOf(photo)
                                    }
                                )
                            }
                        }
                    }

                    Surface(
                        color = Color.White,
                        shadowElevation = 8.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 16.dp)
                                .navigationBarsPadding(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Surface(
                                onClick = onNavigateToFavorites,
                                color = Color(0xFFF2F2F7),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Favorite,
                                        contentDescription = "Favorites",
                                        tint = Color(0xFFFF9500),
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Favorites",
                                        fontWeight = FontWeight.Medium,
                                        color = Color.Black
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Surface(
                                onClick = onNavigateToHidden,
                                color = Color(0xFFF2F2F7),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Hidden",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Hidden",
                                        fontWeight = FontWeight.Medium,
                                        color = Color.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PhotoGridItem(
    photo: Photo,
    onClick: () -> Unit
) {
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .padding(0.5.dp)
            .clip(RoundedCornerShape(2.dp))
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(photo.uri)
                .crossfade(true)
                .build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        if (photo.isFavorite) {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = "Favorite",
                tint = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .size(16.dp)
            )
        }
    }
}
