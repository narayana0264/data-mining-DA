package com.example.ipic.util

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

// DataStore instance
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ipic_preferences")

/**
 * Manages app preferences using DataStore
 * Handles grid columns, PIN, etc.
 */
@Singleton
class PreferencesManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.dataStore
    
    // SharedPreferences for PIN storage (with simple hashing)
    private val securePrefs: SharedPreferences by lazy {
        context.getSharedPreferences("ipic_secure_prefs", Context.MODE_PRIVATE)
    }
    
    // Preference Keys
    private object PreferenceKeys {
        val GRID_COLUMNS = intPreferencesKey("grid_columns")
        const val HIDDEN_PIN = "hidden_pin_hash"
    }
    
    // ============ GRID COLUMNS ============
    
    val gridColumns: Flow<Int> = dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences())
            else throw exception
        }
        .map { preferences ->
            preferences[PreferenceKeys.GRID_COLUMNS] ?: DEFAULT_GRID_COLUMNS
        }
    
    suspend fun setGridColumns(columns: Int) {
        val clampedColumns = columns.coerceIn(MIN_GRID_COLUMNS, MAX_GRID_COLUMNS)
        dataStore.edit { preferences ->
            preferences[PreferenceKeys.GRID_COLUMNS] = clampedColumns
        }
    }
    
    // ============ HIDDEN ALBUM PIN ============
    
    fun hasHiddenPin(): Boolean {
        return securePrefs.contains(PreferenceKeys.HIDDEN_PIN)
    }
    
    fun setHiddenPin(pin: String) {
        val hashedPin = hashPin(pin)
        securePrefs.edit().putString(PreferenceKeys.HIDDEN_PIN, hashedPin).apply()
    }
    
    fun verifyHiddenPin(inputPin: String): Boolean {
        val storedHash = securePrefs.getString(PreferenceKeys.HIDDEN_PIN, null)
        
        // If no PIN set, save this one and return true (first time setup)
        if (storedHash == null) {
            setHiddenPin(inputPin)
            return true
        }
        
        return storedHash == hashPin(inputPin)
    }
    
    fun clearHiddenPin() {
        securePrefs.edit().remove(PreferenceKeys.HIDDEN_PIN).apply()
    }
    
    // Simple SHA-256 hash for PIN storage
    private fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
    
    companion object {
        const val DEFAULT_GRID_COLUMNS = 4
        const val MIN_GRID_COLUMNS = 2
        const val MAX_GRID_COLUMNS = 8
    }
}
