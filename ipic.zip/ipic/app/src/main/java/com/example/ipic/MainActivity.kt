package com.example.ipic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.ipic.ui.screens.FavoritesScreen
import com.example.ipic.ui.screens.HiddenScreen
import com.example.ipic.ui.screens.MainScreen
import com.example.ipic.ui.theme.IPicTheme
import com.example.ipic.viewmodel.GalleryViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            IPicTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    val viewModel: GalleryViewModel = hiltViewModel()
                    
                    // Simple navigation state
                    var currentScreen by remember { mutableStateOf("main") }
                    
                    when (currentScreen) {
                        "main" -> {
                            MainScreen(
                                viewModel = viewModel,
                                onNavigateToFavorites = { currentScreen = "favorites" },
                                onNavigateToHidden = { currentScreen = "hidden" }
                            )
                        }
                        "favorites" -> {
                            FavoritesScreen(
                                viewModel = viewModel,
                                onBack = { currentScreen = "main" }
                            )
                        }
                        "hidden" -> {
                            HiddenScreen(
                                viewModel = viewModel,
                                onBack = { currentScreen = "main" }
                            )
                        }
                    }
                }
            }
        }
    }
}
