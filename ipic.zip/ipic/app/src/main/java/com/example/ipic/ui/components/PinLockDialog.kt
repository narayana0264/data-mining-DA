package com.example.ipic.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * PIN Lock Dialog for Hidden album
 * iOS-style numeric keypad
 * 
 * @param onDismiss Called when dialog is dismissed
 * @param onPinEntered Called when PIN is entered. Return true if PIN is valid, false otherwise
 * @param isSettingPin If true, user is setting a new PIN. If false, user is entering existing PIN
 * @param pinLength Length of PIN (default 4)
 */
@Composable
fun PinLockDialog(
    onDismiss: () -> Unit,
    onPinEntered: (String) -> Boolean,
    isSettingPin: Boolean = false,
    pinLength: Int = 4
) {
    var enteredPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var isConfirmStep by remember { mutableStateOf(false) }
    var isError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    
    val title = when {
        isSettingPin && !isConfirmStep -> "Set PIN"
        isSettingPin && isConfirmStep -> "Confirm PIN"
        else -> "Enter PIN"
    }
    
    val subtitle = when {
        isSettingPin && !isConfirmStep -> "Create a $pinLength-digit PIN to protect your hidden photos"
        isSettingPin && isConfirmStep -> "Re-enter your PIN to confirm"
        else -> "Enter your PIN to unlock hidden photos"
    }
    
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .statusBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(60.dp))
                
                // Lock icon
                Text(
                    text = if (isSettingPin) "🔐" else "🔒",
                    fontSize = 56.sp
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Title
                Text(
                    text = title,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Subtitle
                Text(
                    text = subtitle,
                    fontSize = 15.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )
                
                Spacer(modifier = Modifier.height(40.dp))
                
                // PIN dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    repeat(pinLength) { index ->
                        val currentPin = if (isConfirmStep) confirmPin else enteredPin
                        PinDot(
                            isFilled = index < currentPin.length,
                            isError = isError
                        )
                    }
                }
                
                // Error message
                if (isError) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = errorMessage,
                        color = Color(0xFFFF3B30),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                Spacer(modifier = Modifier.height(48.dp))
                
                // Numeric keypad
                NumericKeypad(
                    onNumberClick = { number ->
                        isError = false
                        
                        if (isSettingPin) {
                            if (!isConfirmStep) {
                                // First entry - setting PIN
                                if (enteredPin.length < pinLength) {
                                    enteredPin += number
                                    if (enteredPin.length == pinLength) {
                                        // Move to confirm step
                                        isConfirmStep = true
                                    }
                                }
                            } else {
                                // Second entry - confirming PIN
                                if (confirmPin.length < pinLength) {
                                    confirmPin += number
                                    if (confirmPin.length == pinLength) {
                                        if (confirmPin == enteredPin) {
                                            // PINs match - save and close
                                            onPinEntered(confirmPin)
                                        } else {
                                            // PINs don't match - reset
                                            isError = true
                                            errorMessage = "PINs don't match. Try again."
                                            enteredPin = ""
                                            confirmPin = ""
                                            isConfirmStep = false
                                        }
                                    }
                                }
                            }
                        } else {
                            // Entering existing PIN
                            if (enteredPin.length < pinLength) {
                                enteredPin += number
                                if (enteredPin.length == pinLength) {
                                    val success = onPinEntered(enteredPin)
                                    if (!success) {
                                        isError = true
                                        errorMessage = "Incorrect PIN. Try again."
                                        enteredPin = ""
                                    }
                                }
                            }
                        }
                    },
                    onBackspaceClick = {
                        if (isConfirmStep && confirmPin.isNotEmpty()) {
                            confirmPin = confirmPin.dropLast(1)
                        } else if (!isConfirmStep && enteredPin.isNotEmpty()) {
                            enteredPin = enteredPin.dropLast(1)
                        }
                        isError = false
                    }
                )
                
                Spacer(modifier = Modifier.weight(1f))
                
                // Cancel button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.padding(bottom = 32.dp)
                ) {
                    Text(
                        text = "Cancel",
                        color = Color(0xFF007AFF),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun PinDot(
    isFilled: Boolean,
    isError: Boolean
) {
    Box(
        modifier = Modifier
            .size(16.dp)
            .clip(CircleShape)
            .background(
                when {
                    isError -> Color(0xFFFF3B30)
                    isFilled -> Color(0xFF007AFF)
                    else -> Color(0xFFE5E5EA)
                }
            )
    )
}

@Composable
private fun NumericKeypad(
    onNumberClick: (String) -> Unit,
    onBackspaceClick: () -> Unit
) {
    val keys = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("", "0", "del")
    )
    
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        keys.forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                row.forEach { key ->
                    when (key) {
                        "" -> {
                            // Empty space
                            Spacer(modifier = Modifier.size(72.dp))
                        }
                        "del" -> {
                            // Backspace button
                            KeypadButton(onClick = onBackspaceClick) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                                    contentDescription = "Delete",
                                    tint = Color.Black,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        else -> {
                            // Number button
                            KeypadButton(
                                onClick = { onNumberClick(key) }
                            ) {
                                Text(
                                    text = key,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KeypadButton(
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(Color(0xFFF2F2F7))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
