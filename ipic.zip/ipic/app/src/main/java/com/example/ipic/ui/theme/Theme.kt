package com.example.ipic.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Light-only color scheme (iOS White Theme)
private val LightColorScheme = lightColorScheme(
    primary = Blue,
    onPrimary = White,
    primaryContainer = Blue,
    onPrimaryContainer = White,
    secondary = Gray,
    onSecondary = White,
    secondaryContainer = Gray5,
    onSecondaryContainer = Black,
    tertiary = Indigo,
    onTertiary = White,
    tertiaryContainer = Gray6,
    onTertiaryContainer = Black,
    error = Red,
    onError = White,
    errorContainer = Red,
    onErrorContainer = White,
    background = White,
    onBackground = Black,
    surface = White,
    onSurface = Black,
    surfaceVariant = Gray6,
    onSurfaceVariant = Gray,
    outline = Separator,
    outlineVariant = Gray5,
    inverseSurface = Black,
    inverseOnSurface = White,
    inversePrimary = Blue,
    surfaceTint = Blue,
    scrim = Black
)

@Composable
fun IPicTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = LightColorScheme
    val view = LocalView.current
    
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            // White status bar with dark icons
            window.statusBarColor = Color.White.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = true
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
