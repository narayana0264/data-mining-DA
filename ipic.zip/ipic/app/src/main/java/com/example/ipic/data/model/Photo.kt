package com.example.ipic.data.model

import android.net.Uri
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a photo in the gallery
 * Core entity that holds photo metadata and flags
 */
@Entity(tableName = "photos")
data class Photo(
    @PrimaryKey
    val id: Long,                          // MediaStore ID
    val uri: String,                       // Content URI as string
    val displayName: String,               // File name
    val dateTaken: Long,                   // Timestamp when photo was taken
    val dateModified: Long,                // Timestamp when photo was modified
    val size: Long,                        // File size in bytes
    val width: Int,                        // Image width
    val height: Int,                       // Image height
    val mimeType: String,                  // MIME type (image/jpeg, etc.)
    val bucketId: String?,                 // Folder/bucket ID
    val bucketName: String?,               // Folder/bucket display name
    val path: String?,                     // Full file path
    val isFavorite: Boolean = false,       // Favorite flag
    val isHidden: Boolean = false,         // Hidden flag
    val isDeleted: Boolean = false,        // Soft delete flag
    val deletedAt: Long? = null            // When photo was deleted (for 30-day recovery)
) {
    fun getContentUri(): Uri = Uri.parse(uri)
    
    companion object {
        const val DELETION_PERIOD_DAYS = 30
        const val DELETION_PERIOD_MS = DELETION_PERIOD_DAYS * 24 * 60 * 60 * 1000L
    }
}

/**
 * Simplified photo data for grid display
 */
data class PhotoThumbnail(
    val id: Long,
    val uri: String,
    val dateTaken: Long,
    val isFavorite: Boolean,
    val aspectRatio: Float
)

/**
 * Photo grouped by date for timeline display
 */
data class PhotoGroup(
    val date: String,           // Formatted date string
    val timestamp: Long,        // Date timestamp for sorting
    val photos: List<PhotoThumbnail>
)
